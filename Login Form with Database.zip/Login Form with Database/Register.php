
<html>
	<head>
		<title>Register Page</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.RegisterPage{
				width:600px;
				hight:600px;
				margin: 0 auto;
				border: 2px solid black;
				padding:20px;
				}
				
			.btn {
				border: none;
				color:black;
				padding: 14px 28px;
				font-size: 16px;
				cursor: pointer;
				}
				
			.login {
				background-color:#F8F8FF;
				}
			
			.login:hover{
				background-color:#FF1493;
				}
				
			.register {
				background-color:#FF1493;
				} 

			.reset {
				background-color:#F8F8FF;
				}
					
			.reset:hover{
				background-color:#FF1493;
				}
				
			.registernow {
				background-color:#F8F8FF;
				}
			.registernow:hover{
				background-color:#FF1493;
				}				
			
		</style>
		<script type="text/javascript">
			function myFunction() {
			  var x = document.getElementById("psw");
			  if (x.type === "password") {
			    x.type = "text";
			  } else {
			    x.type = "password";
			  }
			}	

			function Validate() {
		        var password = document.getElementById("psw").value;
		        var confirmPassword = document.getElementById("rpsw").value;
		        if (password != confirmPassword) {
		            alert("Passwords do not match.");
		            return false;
		        }
        		return true;
  		    }	
		</script>

	</head>
	<body>
		<div class="RegisterPage">
			<h1>Login or Register </h1>
			<hr/>
			<a href="Login.php">
			<button class="btn login">Login</button>
			</a>
			<button class="btn register">Register</button>
			
			<hr/>
			<br>
			<form method="post">
			<table>
				<tr>
					<td><i class="fa fa-user" style="font-size:25px;"></i></td>
					<td><input type="username" id="username" name="username" placeholder="User Name" required></td>
				</tr>
				<tr>	</tr>
				<tr>
					<td><i class="fa fa-phone" style="font-size:25px;"></i></td>
					<td><input type="text" id="mobile" name="mobile" placeholder="Enter Your Mobile Number" required></td>
				</tr>
				<tr>	</tr>
				<tr>
					<td><i class="fa fa-envelope" style="font-size:25px;"></i></td>
					<td><input type="email" id="email" name="email" placeholder="Email Id" required></td>

				</tr>
				<tr>	</tr>
				<tr>
					<td><i class="fa fa-lock" style="font-size:25px;"></i></td>
					<td><input type="password" id="psw" name="psw" placeholder="Password" required></td>
					<td><input type="checkbox" onclick="myFunction()">Show Password</td>
				</tr>
				<tr>	</tr>
				<tr>
					<td><i class="fa fa-lock" style="font-size:25px;"></i></td>
					<td><input type="password" id="rpsw" name="rpsw" placeholder="Repeat Password" required></td>
				</tr>
			</table>
			<button class="btn registernow" type="submit" name="register" onclick="return Validate()">Register Now</button>
			</form>
		<div>
	</body>
</html>




<?php
$link = mysqli_connect("localhost", "root", "", "DB");

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

if(isset($_POST['register'])){ 
    $username1 = $_POST['username'];
    $mobile1 = $_POST['mobile'];
    $email1 = $_POST['email'];
    $psw1 = $_POST['psw'];
    $rpsw1 = $_POST['rpsw'];

    $sql = "INSERT INTO register (username , mobile , email , psw , rpsw) VALUES('$username1', '$mobile1', '$email1' , '$psw1' , '$rpsw1')";
    if(mysqli_query($link, $sql)) {
    	header("location:abc.php");
	    		exit();
        
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
}
mysqli_close($link);

?>

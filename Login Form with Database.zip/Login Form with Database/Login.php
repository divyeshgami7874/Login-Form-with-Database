 <html>
	<head>
		<title>Login Page</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.loginPage{
				width:600px;
				hight:600px;
				margin: 0 auto;
				border: 2px solid black;
				padding:20px;
				}
				
			.btn {
				border: none;
				color:black;
				padding: 14px 28px;
				font-size: 16px;
				cursor: pointer;
				}
				
			.login {
				background-color:#FF1493;
				}

			.register {
				background-color:#F8F8FF;
				} 
				
			.register:hover{
				background-color:#FF1493;
				}

			.reset {
				background-color:#F8F8FF;
				}
					
			.reset:hover{
				background-color:#FF1493;
				}
				
			.loginnow {
				background-color:#F8F8FF;
				}
			.loginnow:hover{
				background-color:#FF1493;
				}
			
			
		</style>
	</head>
	<body>
		<div class="loginPage">
			<h1>Login or Register </h1>
			<hr/>
			<button class="btn login">Login</button>
			<a href="Register.php">
			<button class="btn register">Register </button>
			</a>
			
			<hr/>
			<br>
			<form method="post">
			<table>
				<tr>
					<td><i class="fa fa-user" style="font-size:25px;"></i></td>
					<td><input type="username" name="username" placeholder="User Name" required></td>
				</tr>
				<tr>	</tr>
				<tr>
					<td><i class="fa fa-lock" style="font-size:25px;"></i></td>
					<td><input type="password" name="psw" placeholder="Password" required></td>
				</tr>
			</table>
			<input type="checkbox" name="checkbox"> Remember Me!
			<br><br>
			<button class="btn loginnow" type="submit" name="login">Login Now</button>

			</form>
			<a href="Reset.php">
			<button class="btn reset">Reset Password</button>
			</a>
		<div>
	</body>
</html>



<?php
 	$link=mysqli_connect("localhost", "root", "", "DB");

 	if(isset($_POST['login'])){ 
	    $username1 = $_POST['username'];
	    $psw1 = $_POST['psw'];

	    $sql="select * from register where username='$username1'";
	    $result=mysqli_query($link,$sql);

	    if($row=mysqli_fetch_array($result,MYSQLI_BOTH)){
	    	if($psw1==$row['psw']){
	    		header("location:abc.php");
	    		exit();
	    	}
	    	else
	    		echo "Invelid Password";
	    }
	    else
	    	echo "Invelid UserName";
	}

?>

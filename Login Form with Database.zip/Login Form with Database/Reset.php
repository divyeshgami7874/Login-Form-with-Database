
<html>
	<head>
		<title>Reset Password Page</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.ResetPage{
				width:600px;
				hight:600px;
				margin: 0 auto;
				border: 2px solid black;
				padding:20px;
				}
				
			.btn {
				border: none;
				color:black;
				padding: 14px 28px;
				font-size: 16px;
				cursor: pointer;
				}
				
			.login {
				background-color:#F8F8FF;
				}
			
			.login:hover{
				background-color:#FF1493;
				}
				
			.register {
				background-color:#F8F8FF;
				} 

			.register:hover{
				background-color:#F8F8FF;
				}
				
			.reset {
				background-color:#FF1493;
				}
				
			.resetpassword {
				background-color:#F8F8FF;
				}
			.resetpassword:hover{
				background-color:#FF1493;
				}
				
				
			
		</style>
	</head>
	<body>
		<div class="ResetPage">
			<h1>Login or Register </h1>
			<hr/>
			<button class="btn reset">Reset Password</button>
			<hr/>
			<form method="post">
			<table>
				<tr>
					<td><i class="fa fa-envelope" style="font-size:25px;"></i></td>
					<td><input type="email" name="email" placeholder="Email Id" required></td>
				</tr>
			</table>
			<button class="btn resetpassword" onclick="alert('Password Send your Email id!')">Reset Password</button>
			</form>
		<div>
	</body>
</html>